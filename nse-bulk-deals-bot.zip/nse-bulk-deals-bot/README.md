# NSE Bulk/Block Deals — Daily Telegram Alert

Automatically fetches NSE's Bulk Deals, Block Deals, and Short Deals data
every trading day after market close and sends it to you on Telegram.
Runs for free using GitHub Actions — no server or computer needs to stay on.

## What you already have
- Telegram Bot Token: from @BotFather
- Telegram Chat ID: `144228520`

## Setup (10 minutes, one-time)

### 1. Create a GitHub repository
1. Go to https://github.com/new
2. Name it e.g. `nse-bulk-deals-bot`, set to **Private** or Public, click **Create repository**

### 2. Upload these files
Upload all files from this project (keeping the folder structure, including
the `.github/workflows/daily-alert.yml` file) to your new repo. Easiest way:
- On the repo page, click **Add file → Upload files**
- Drag in `nse_bulk_deals_alert.py`, `requirements.txt`, `README.md`
- For the workflow file, you must create the path manually: click **Add file →
  Create new file**, type `.github/workflows/daily-alert.yml` as the filename
  (GitHub auto-creates the folders), then paste the contents in.

### 3. Add your secrets
1. In your repo, go to **Settings → Secrets and variables → Actions**
2. Click **New repository secret**
3. Add:
   - Name: `TELEGRAM_BOT_TOKEN` → Value: your bot token
   - Name: `TELEGRAM_CHAT_ID` → Value: `144228520`

### 4. Test it
1. Go to the **Actions** tab in your repo
2. Click **Daily NSE Bulk Deals Alert** on the left
3. Click **Run workflow** (top right) → **Run workflow**
4. Wait ~30 seconds, check your Telegram — you should get a message

### 5. Done
From now on, it runs automatically every trading day at **6:00 PM IST**
(Mon–Fri) and messages you the day's bulk/block/short deals. No further
action needed.

## Notes
- NSE sometimes changes its API or adds stronger bot-blocking. If the alert
  stops working, check the **Actions** tab for the failed run logs — the
  script also sends you a Telegram message if it fails to fetch data.
- You can change the alert time by editing the `cron` line in
  `.github/workflows/daily-alert.yml`. Format is UTC time, and IST = UTC + 5:30.
- You can test locally too:
  ```bash
  pip install -r requirements.txt
  export TELEGRAM_BOT_TOKEN="your_token"
  export TELEGRAM_CHAT_ID="144228520"
  python nse_bulk_deals_alert.py
  ```
