"""
NSE Bulk/Block Deals -> Telegram Alert
----------------------------------------
Fetches today's Bulk Deals, Block Deals, and Short Deals from NSE India
and sends a formatted summary to a Telegram chat via a Bot.

Environment variables required (set as GitHub Actions secrets, see README):
    TELEGRAM_BOT_TOKEN  - Your Telegram bot token from BotFather
    TELEGRAM_CHAT_ID    - Your Telegram chat ID

Run manually:
    python nse_bulk_deals_alert.py
"""

import os
import sys
import time
import requests

NSE_HOME_URL = "https://www.nseindia.com"
NSE_DEALS_URL = "https://www.nseindia.com/api/snapshot-capital-market-largedeals"

TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID")

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.nseindia.com/market-data/large-deals",
}


def fetch_nse_deals(max_retries: int = 3) -> dict:
    """Fetch bulk/block/short deals JSON from NSE. Needs a warmed-up session
    because NSE blocks requests without prior cookies from the homepage."""
    session = requests.Session()
    session.headers.update(HEADERS)

    for attempt in range(1, max_retries + 1):
        try:
            # Step 1: hit homepage to collect cookies (NSE anti-bot requirement)
            session.get(NSE_HOME_URL, timeout=10)
            time.sleep(1)

            # Step 2: hit the actual data endpoint
            resp = session.get(NSE_DEALS_URL, timeout=10)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            print(f"[Attempt {attempt}] Failed to fetch NSE data: {e}")
            time.sleep(2)

    raise RuntimeError("Could not fetch NSE data after retries")


def format_deal_section(title: str, rows: list, limit: int = 15) -> str:
    if not rows:
        return f"*{title}*: No data reported today.\n"

    lines = [f"*{title}* ({len(rows)} deals)"]
    for row in rows[:limit]:
        symbol = row.get("symbol") or row.get("SYMBOL") or "?"
        client = row.get("clientName") or row.get("CLIENT_NAME") or "?"
        buy_sell = row.get("buySell") or row.get("BUY_SELL") or "?"
        qty = row.get("qty") or row.get("QTY") or row.get("quantityTraded") or "?"
        price = row.get("watp") or row.get("WATP") or row.get("tradePrice") or "?"
        lines.append(f"• {symbol} | {client} | {buy_sell} | Qty: {qty} | Price: {price}")

    if len(rows) > limit:
        lines.append(f"...and {len(rows) - limit} more")

    return "\n".join(lines) + "\n"


def build_message(data: dict) -> str:
    from datetime import datetime

    today = datetime.now().strftime("%d-%b-%Y")
    header = f"📊 *NSE Bulk/Block Deals — {today}*\n\n"

    bulk = data.get("BULK_DEALS_DATA", [])
    block = data.get("BLOCK_DEALS_DATA", [])
    short = data.get("SHORT_DEALS_DATA", [])

    message = header
    message += format_deal_section("Bulk Deals", bulk) + "\n"
    message += format_deal_section("Block Deals", block) + "\n"
    message += format_deal_section("Short Deals", short)

    return message


def send_telegram_message(text: str, chunk_size: int = 3800):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        raise RuntimeError("TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID not set")

    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"

    # Telegram has a 4096 char limit per message; split into chunks if needed
    for i in range(0, len(text), chunk_size):
        chunk = text[i:i + chunk_size]
        resp = requests.post(url, data={
            "chat_id": TELEGRAM_CHAT_ID,
            "text": chunk,
            "parse_mode": "Markdown",
        }, timeout=10)
        if resp.status_code != 200:
            print(f"Telegram send failed: {resp.status_code} {resp.text}")
        time.sleep(1)


def main():
    try:
        data = fetch_nse_deals()
    except Exception as e:
        error_msg = f"⚠️ Could not fetch NSE bulk deals today.\nReason: {e}"
        print(error_msg)
        try:
            send_telegram_message(error_msg)
        except Exception:
            pass
        sys.exit(1)

    message = build_message(data)
    print(message)
    send_telegram_message(message)
    print("Sent to Telegram successfully.")


if __name__ == "__main__":
    main()
